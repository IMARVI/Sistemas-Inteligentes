class Nodo:

    def __init__(self, estado, padre, accion, costo):
        self.estado = estado
        self.padre = padre
        self.accion = accion
        self.costo = costo
