from Proyecto1 import busquedaNoInformada
busquedaNoInformada([[0,1,2],[4,5,3],[7,8,6]],[[1,2,3],[4,5,6],[7,8,0]], 0)
