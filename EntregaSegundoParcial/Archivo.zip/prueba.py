from Proyecto2 import busquedaAstar

print(busquedaAstar([[4, 1, 2], [0, 5, 3], [7, 8, 6]], [[1, 2, 3], [4, 5, 6], [7, 8, 0]], 1))
